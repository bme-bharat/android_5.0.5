package com.bmebharat.newapp.bmevideoplayer

import android.content.Context
import androidx.media3.common.C
import androidx.media3.exoplayer.ExoPlayer
import java.util.ArrayDeque

object PlayerPool {
    private val pool = ArrayDeque<ExoPlayer>()
    private const val MAX_POOL = 3

    // Get a player from the pool or create a new one
    fun getPlayer(context: Context): ExoPlayer {
        synchronized(pool) {
            return if (pool.isNotEmpty()) pool.pop() else createPlayer(context)
        }
    }

    // Release a player back to the pool or release it if pool is full
    fun releasePlayer(player: ExoPlayer?) {
        player ?: return
        try {
            // Stop playback and reset
            player.stop()
            player.seekTo(0)
            player.clearMediaItems()
            player.repeatMode = ExoPlayer.REPEAT_MODE_OFF
            player.volume = 1f
        } catch (_: Exception) {}

        synchronized(pool) {
            if (pool.size < MAX_POOL) pool.push(player) else player.release()
        }
    }

    // Preload a media item without autoplay
    fun preloadPlayer(context: Context, url: String): ExoPlayer {
        val player = getPlayer(context)
        val mediaItem = androidx.media3.common.MediaItem.fromUri(url)
        player.setMediaItem(mediaItem)
        player.prepare()
        player.playWhenReady = false
        return player
    }

    // Create a fresh ExoPlayer
    private fun createPlayer(context: Context): ExoPlayer {
        return ExoPlayer.Builder(context)
            .setAudioAttributes(
                androidx.media3.common.AudioAttributes.Builder()
                    .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
                    .setUsage(C.USAGE_MEDIA)
                    .build(),
                true
            )
            .build()
    }
}
